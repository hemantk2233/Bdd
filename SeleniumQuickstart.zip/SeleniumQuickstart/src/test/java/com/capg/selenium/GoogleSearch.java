package com.capg.selenium;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleSearch {
	
	static Logger logger=Logger.getLogger(AlertExample.class.getName());
	WebDriver driver;
		
		
		
		@Test
		public void ExampleForAlert() throws InterruptedException{
			
			System.setProperty("webdriver.chrome.driver", "D:\\Jenkins\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.google.co.in/");
			Thread.sleep(2000);
			driver.findElement(By.name("q")).sendKeys("shoe");
			driver.findElement(By.name("btnK")).sendKeys(Keys.ENTER);
			Alert alert = driver.switchTo().alert();
			logger.info(alert.getText());
			alert.accept();
			logger.info("done");
		}

}
