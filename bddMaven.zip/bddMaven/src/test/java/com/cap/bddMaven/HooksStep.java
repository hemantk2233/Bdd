package com.cap.bddMaven;

import cucumber.annotation.After;
import cucumber.annotation.Before;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;


public class HooksStep {
	@Before
	public void beforeScenario() {
		System.out.println("This will run before scenerio");
	}
	
	@After
	public void afterScenario() {
		System.out.println("This will run after scenerio");
	}
	
	
	@Given("^I have a calculator$")
	public void i_have_a_calculator() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  System.out.println("I am a given method");
	}

	@When("^I add -(\\d+) and (\\d+)$")
	public void i_add_and(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("I am a given method");
	}

	@Then("^the result should be (\\d+)$")
	public void the_result_should_be(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("I am a given method");
	}
}
