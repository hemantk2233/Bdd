package com.capg.ConferenceQuickstart;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ConfernceTest {
	
	static Logger logger=Logger.getLogger(ConfernceTest.class.getName());
	WebDriver driver;

	@Test
	public void ConferenceExample() throws InterruptedException{
		try {
		System.setProperty("webdriver.chrome.driver", "D:\\Jenkins\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:9000/ConferenceWeb/conference.html");
		Thread.sleep(2000);
		driver.findElement(By.id("txtFirstName")).sendKeys("Hemant");
		driver.findElement(By.id("txtLastName")).sendKeys("Kumar");
		driver.findElement(By.id("txtEmail")).sendKeys("hemantk2233@gmail.com");
		driver.findElement(By.id("txtPhone")).sendKeys("9789268575");
		Select sel = new Select(driver.findElement(By.name("size")));
		sel.selectByIndex(2);
		driver.findElement(By.id("txtAddress1")).sendKeys("Room-110");
		driver.findElement(By.id("txtAddress2")).sendKeys("Gowlidoody");
		Select sel1 = new Select(driver.findElement(By.name("city")));
		sel1.selectByVisibleText("Hyderabad");
		Select sel2 = new Select(driver.findElement(By.name("state")));
		sel2.selectByVisibleText("Telangana");
		driver.findElement(By.name("memberStatus")).click();
		driver.findElement(By.linkText("Next")).click();
		Alert alert = driver.switchTo().alert();
		logger.info(alert.getText());
		alert.accept();
		logger.info("done");
		
		driver.get("http://localhost:9000/ConferenceWeb/payment.html");
		Thread.sleep(3000);
		driver.findElement(By.id("txtCardholderName")).sendKeys("Hemant Kumar");
		driver.findElement(By.id("txtDebit")).sendKeys("44724635");
		driver.findElement(By.id("txtCvv")).sendKeys("946");
		driver.findElement(By.id("txtMonth")).sendKeys("June");
		driver.findElement(By.id("txtYear")).sendKeys("2020");
		driver.findElement(By.id("btnPayment")).click();
		Alert alert2 = driver.switchTo().alert();
		logger.info(alert2.getText());
		alert2.accept();
		logger.info("done");
		}
		finally {
			driver.close();
		}
		
	}
}
