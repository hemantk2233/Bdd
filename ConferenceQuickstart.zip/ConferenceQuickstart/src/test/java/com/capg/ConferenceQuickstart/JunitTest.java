package com.capg.ConferenceQuickstart;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class JunitTest {
	
	static Logger logger=Logger.getLogger(JunitTest.class.getName());
	WebDriver driver;
	
	@Test
	public void JunitExample(){
		System.setProperty("webdriver.chrome.driver", "D:\\Jenkins\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:9000/ConferenceWeb/capgemini.html");
		String actualdata=driver.findElement(By.name("Capgemini")).getAttribute("value");
		logger.info(actualdata);
		Assert.assertEquals("Capgemini", actualdata);
		

		
}
}
