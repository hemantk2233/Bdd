package com.cap.log4j.Log4jTesting;

import org.apache.log4j.Logger;

public class App 
{
	static Logger logger = Logger.getLogger(App.class.getName());
    public static void main( String[] args )
    {
    	
        logger.info( "Hello Hemant" );
    }
}
