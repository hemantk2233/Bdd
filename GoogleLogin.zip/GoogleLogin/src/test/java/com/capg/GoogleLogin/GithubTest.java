package com.capg.GoogleLogin;


import java.util.logging.Logger;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;


public class GithubTest {
	
	static Logger logger=Logger.getLogger(GithubTest.class.getName());
	static WebDriver driver;
		
	@Before
	public void initialization() {
		System.setProperty("webdriver.chrome.driver", "D:\\Jenkins\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	
			
			
			@Test
			public void GithubTest() {
			try {
				github_Login_page();
				i_enter_admin_and_admin();
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
				
				
				@Given("^github Login page$")
				public static void github_Login_page() throws Throwable {
					driver.get("https://github.com/login");
				    //throw new PendingException();
				}

				@When("^I enter admin and admin$")
				public static void i_enter_admin_and_admin() throws Throwable {
					driver.findElement(By.id("login_field")).sendKeys("hemantk2233");
					driver.findElement(By.id("password")).sendKeys("Hemu@1234");
					driver.findElement(By.name("commit")).click();
				    //throw new PendingException();
				}

}