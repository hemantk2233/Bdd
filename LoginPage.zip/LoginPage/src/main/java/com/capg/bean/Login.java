package com.capg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Login {
	
	@FindBy(how=How.ID,id="user")
	private WebElement UserName;
	
	@FindBy(how=How.ID,id="pass")
	private WebElement Password;
	
	@FindBy(how=How.ID,id="sub")
	private WebElement submit;

	public void click() {
		submit.click();
	}

	public String getUserName() {
		return UserName.getAttribute("value");
	}

	public void setUserName(String userName) {
		this.UserName.sendKeys(userName);
	}
	
	public String getPassword() {
		return Password.getAttribute("value");
	}
	
	public void setPassword(String password) {
		this.Password.sendKeys(password);
	}

	
	
	}

	
