package com.capg.StepDef;


import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capg.bean.Login;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginTest {
	
	static Logger logger=Logger.getLogger(LoginTest.class.getName());
	static WebDriver driver;
	private Login pagebean; 
	
	@Before
	public void initialization() {
		System.setProperty("webdriver.chrome.driver", "D:\\Jenkins\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		pagebean = new Login();
		 PageFactory.initElements(driver, pagebean);
	}

	
	@Given("^I enter details in Login page$")
	public void i_enter_details_in_Login_page() throws Throwable {
	   driver.get("http://localhost:9000/LoginWeb/login.html"); 
	  
	}
	
	@When("^I enter <username> and <password>$")
	public void i_enter_username_and_password() throws Throwable {
	   pagebean.setUserName("hemant");
	   pagebean.setPassword("hola");
	   pagebean.click();
	}
	@Then("^I get a thankyou page$")
	public void i_get_a_thankyou_page() throws Throwable {
	  
	}
}